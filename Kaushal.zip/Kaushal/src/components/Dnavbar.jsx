import React from 'react'
import './Dnavbar.css'
const Dnavbar = () => {
  return (
    <div className='Dnav'>
         <h1>VAPP</h1>
    </div>
  )
}

export default Dnavbar