import React ,{useState}from "react";
import "./SAP.css";
import download from "../download.png";
import execute from "../execute.png"
import { FaArrowRightLong } from "react-icons/fa6";
import { IoCloseSharp } from "react-icons/io5";
import { MdDoubleArrow } from "react-icons/md";
import { FaAngleDoubleDown } from "react-icons/fa";
import { Link } from "react-router-dom";
import { FaArrowLeft } from "react-icons/fa6";
import { RiArrowLeftDoubleLine } from "react-icons/ri";
const SAP = () => {
  const [open, setOpen] = useState(false);
  const [openDrop1, setOpenDrop1] = useState(false);
  const [openDrop2, setOpenDrop2] = useState(false);
  const [openDrop3, setOpenDrop3] = useState(false);
  const [selectedOptions1, setSelectedOptions1] = useState([]);
  const [selectedOptions2, setSelectedOptions2] = useState([]);
  const [selectedOptions3, setSelectedOptions3] = useState([]);

  const handleCheckboxChange1 = (option) => {
    if (selectedOptions1.includes(option)) {
      setSelectedOptions1(selectedOptions1.filter((item) => item !== option));
    } else {
      setSelectedOptions1([...selectedOptions1, option]);
    }
  };
  const handleCheckboxChange2 = (option) => {
    if (selectedOptions2.includes(option)) {
      setSelectedOptions2(selectedOptions2.filter((item) => item !== option));
    } else {
      setSelectedOptions2([...selectedOptions2, option]);
    }
  };

  const handleCheckboxChange3 = (option) => {
    if (selectedOptions3.includes(option)) {
      setSelectedOptions3(selectedOptions3.filter((item) => item !== option));
    } else {
      setSelectedOptions3([...selectedOptions3, option]);
    }
  };

  const options1 = ["AP", "AR", "GL"];
  const options2 = ["R4", "ER", "4T"];
  const options3 = ["R4", "ER", "4T"];

  const handleSubmit = () => {
    console.log(selectedOptions1);
    console.log(selectedOptions2);
    console.log(selectedOptions3);
  };

  const handleCancel = () => {
    setSelectedOptions1([]);
    setSelectedOptions2([]);
    setSelectedOptions3([]);
  };
  return (
    <div className="sapmain">
      <div className="navbar1">
        <FaArrowLeft/> <Link to="/authpage" className="home_link">Homepage</Link>
        </div>
      <div className="sapcont">
       
      <div className="sapcard">
        <div className="ii1">
          <label>API KEY</label>
          <input type="text" className="APIIN" placeholder="Enter your API key"></input>
        </div>
        <div className="ii1">
            <label>OR</label>
        </div>
        <div className="ii1">
          <p>Step 1 :</p>
          <input
            type="file"
            id="fileInput"
            accept=".jpg, .jpeg, .png" /* Optional: specify accepted file types */
            className="filein"
          />
        </div>
        <div className="ii1">
          <p>Step 2 :</p>
          <input
            type="file"
            id="fileInput"
            accept=".jpg, .jpeg, .png" /* Optional: specify accepted file types */
            className="filein"
          />
        </div>
        <div className="ii1"><button className="button-19"><img src={execute} className="dimg"/> Execute</button></div>
       <div className="ii1"><button className="button-18"><img src={download} className="dimg"/> Download The Report</button></div>
      </div>

      <div>
      <div>
      <div className="drawer-cont">
        <i onClick={() => setOpen(!open)}>
          <RiArrowLeftDoubleLine />
        </i>
      </div>
      {open && (
        <div className="drawer">
          <i onClick={() => setOpen(!open)} className="close">
            <IoCloseSharp />
          </i>

          <div className="dropdown1">
            <label onClick={() => setOpenDrop1(!openDrop1)}>
              {" "}
              {openDrop1 ? <FaAngleDoubleDown /> : <MdDoubleArrow />}R2R
            </label>
            {openDrop1 && (
              <div className="drop1">
                <div className="checkbox-dropdown">
                  {options1.map((option, index) => (
                    <label key={index}>
                      <input
                        type="checkbox"
                        value={option}
                        checked={selectedOptions1.includes(option)}
                        onChange={() => handleCheckboxChange1(option)}
                      />
                      {option}
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="dropdown2">
            <label onClick={() => setOpenDrop2(!openDrop2)}>
              {" "}
              {openDrop2 ? <FaAngleDoubleDown /> : <MdDoubleArrow />} A2A
            </label>
            {openDrop2 && (
              <div className="drop2">
                <div className="checkbox-dropdown">
                  {options2.map((option, index) => (
                    <label key={index}>
                      <input
                        type="checkbox"
                        value={option}
                        checked={selectedOptions2.includes(option)}
                        onChange={() => handleCheckboxChange2(option)}
                      />
                      {option}
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>
          <div className="dropdown3">
            <label onClick={() => setOpenDrop3(!openDrop3)}>
              {" "}
              {openDrop3 ? <FaAngleDoubleDown /> : <MdDoubleArrow />} A2A
            </label>
            {openDrop3 && (
              <div className="drop2">
                <div className="checkbox-dropdown">
                  {options3.map((option, index) => (
                    <label key={index}>
                      <input
                        type="checkbox"
                        value={option}
                        checked={selectedOptions3.includes(option)}
                        onChange={() => handleCheckboxChange3(option)}
                      />
                      {option}
                    </label>
                  ))}
                </div>
              </div>
            )}
          </div>

          <div className="actionbtns">
            <button onClick={handleSubmit}>submit</button>
            <button onClick={handleCancel}>Cancel</button>
          </div>
        </div>
      )}
      </div>
      </div>
        </div>
        
    </div>
  );
};

export default SAP;
