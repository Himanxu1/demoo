import React from 'react'
import './Homepage.css'
import Sidebar from './Sidebar'
import { motion } from 'framer-motion'

const Homepage = () => {
  return (
    <div className='Main'>

      <div className='landingpage'>
<motion.div
initial={{opacity:0,y:-10}}
animate={{opacity:1,y:10}}
transition={{duration:0.5}}
>

      <div className='mainname'>
        Welcome to VAPP
      </div>
      <div className='motto'>
      Application for <span className='highlight'>Business Needs.</span> 
      </div>
</motion.div>
      </div>

    </div>
  )
}

export default Homepage