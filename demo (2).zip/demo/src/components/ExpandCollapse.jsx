import React from "react";
import { useState } from "react";
import "./ExpandCollapse.css";
import Checkbox from "./CheckBox";
import { FaAngleDoubleDown } from "react-icons/fa";
import { MdDoubleArrow } from "react-icons/md";
const ExpandCollapse = () => {
  const [isExpanded1, setIsExpanded1] = useState(false);
  const [selectedOption1, setSelectedOption1] = useState("");
  const [isExpanded2, setIsExpanded2] = useState(false);
  const [selectedOption2, setSelectedOption2] = useState("");
  const [selectedApplicationOptions, setSelectedApplicationOptions] = useState([]);
  const [selectedBoardingOption, setSelectedBoardingOption] = useState([]);

  const [checkedOne, setCheckedOne] = React.useState(false);
  const [checkedTwo, setCheckedTwo] = React.useState(false);

  
  const handleChangeOne = () => {
    setCheckedOne(!checkedOne);
  };

  const handleChangeTwo = () => {
    setCheckedTwo(!checkedTwo);
  };


  const handleExpandCollapse1 = () => {
    setIsExpanded1(!isExpanded1);
    setSelectedOption1(""); // Reset selected option when collapsing
  };

  const handleExpandCollapse2 = () => {
    setIsExpanded2(!isExpanded2);
    setSelectedOption2(""); // Reset selected option when collapsing
  };

 

  const handleApplicationCheckboxes = (option) => {
    if (selectedApplicationOptions.includes(option)) {
      setSelectedApplicationOptions(selectedApplicationOptions.filter((item) => item !== option));
    } else {
      setSelectedApplicationOptions([...selectedApplicationOptions, option]);
    }
  };

  const handleBoardingCheckboxes = (option) => {
    if (selectedBoardingOption.includes(option)) {
      setSelectedBoardingOption(selectedBoardingOption.filter((item) => item !== option));
    } else {
      setSelectedBoardingOption([...selectedBoardingOption, option]);
    }
  };
  const applicationOption = ["Salesforce","Oracle","Coupa","Netsuite","Workday"];
  const boardingOption = ["on boarding","off boarding"];

  return (
    <div className="ecmain">
      <div className="ecsb"></div>
      <div className="btnspan">
        <div className="collapse1">
          <div>
          <button onClick={handleExpandCollapse1} className="ectoggle">
          {isExpanded1 ? <FaAngleDoubleDown /> : <MdDoubleArrow /> }
          </button>
          </div>
          <div className="collapse-div">
          <span className="ssec">Select the Services</span>
          {isExpanded1 && (
            <div className="expandclass">
               {boardingOption.map((option, index) => (
                    <label key={index}>
                      <input
                        type="checkbox"
                        value={option}
                        checked={selectedBoardingOption.includes(option)}
                        onChange={() => handleBoardingCheckboxes(option)}
                      />
                      {option}
                      
                    </label>
                  ))}
            </div>
          )}
          </div>

        </div>

        <div className="collapse1">
          <div>
          <button onClick={handleExpandCollapse2} className="ectoggle">
          {isExpanded2 ? <FaAngleDoubleDown /> : <MdDoubleArrow />}
          </button>
          </div>
          <div className="collapse-div">

          <span className="ssec">Select the Application</span>
          {isExpanded2 && (
            <div className="expandclass">
            {applicationOption.map((option, index) => (
                    <label key={index}>
                      <input
                        type="checkbox"
                        value={option}
                        checked={selectedApplicationOptions.includes(option)}
                        onChange={() => handleApplicationCheckboxes(option)}
                      />
                      {option}
                      
                    </label>
                  ))}
            </div>
          )}
            </div>
        </div>
        <div className="btncontainer">
          <button className="Gobtn">Go</button>
          <button className="canbtn">Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default ExpandCollapse;
