import './Solutions.css'
const Solutions = () =>{
    return (
        <div className="main_div">
           <h1 className='heading'>Solutions</h1>
           <div className='card_wrapper'>

           <div className='card_s'>
            <p className='card_content'>License Management</p>
           </div>

           <div className='card_s'>
           <p className='card_content'>SOD</p>
           </div>

            <div className='card_s'>
           <p className='card_content'>User Administration</p>
           </div>
           <div className='card_s'>
           <p className='card_content'>Integration</p>
           </div>

           </div>
        </div>
    )
}

export default Solutions