import './Services.css'
const Services = () =>{
    return (
        <div className="main_div">
            <h1 className="heading">Services</h1>
            <div className='card_wrapper'>

<div className='card_s'>
 <p className='card_content'>License Audit</p>
</div>

<div className='card_s'>
<p className='card_content'>ITGC Audit</p>
</div>

 <div className='card_s'>
<p className='card_content'>Business Process Optimization</p>
</div>


</div>
        </div>
    )
}

export default Services