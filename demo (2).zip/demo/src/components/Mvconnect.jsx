import React from 'react';
import './Mvconnect.css';
import plus from '../plus.png';
import { Link, useNavigate } from 'react-router-dom';
import { FaArrowLeft } from 'react-icons/fa';
const Mvconnect = () => {
    const navigate = useNavigate();
  return (
    <div className='modmain'>
      <div>
      <div className="navbar1">
        <FaArrowLeft/> <Link to="/authpage" className="home_link">Homepage</Link>
        </div>
        <div className='modnavbar'>VConnect</div>
      </div>
        <div className='modmainview'>
        <div className='addflow'><button className='addflowbtn' onClick={() => navigate('/mvconnect')}><img src={plus} className='llogo' />Add new FLow</button></div>
        <div className='prevflows'>You Can See Your created Flows Here</div>
        </div>
    </div>
  )
}

export default Mvconnect