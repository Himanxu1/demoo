import './CaseStudies.css'
const CaseStudies = () =>{
    return (
        <div className="main_div">
            <h1 className="heading">Case Studies</h1>
            <div className='card_wrapper'>

<div className='card_s'>
 <p className='card_content'>CS1</p>
</div>

<div className='card_s'>
<p className='card_content'>CS2</p>
</div>

 <div className='card_s'>
<p className='card_content'>CS3</p>
</div>


</div>
        
       </div>
    )
}

export default CaseStudies