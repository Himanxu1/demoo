import React, { useState } from 'react';
import './Dropdowncomp.css';
import plus from '../plus.png';
import minus from '../minus.png';
import cross from '../cross-button.png';
import rri from '../rright.png'
function DropdownComponent({ items,dropdownId,value,handleSelection,handleSelections,ppname }) {
  const [selectedValue, setSelectedValue] = useState('');
  const [isDivVisible, setDivVisibility] = useState(false);
  const [data, setData] = useState([
    { source: 'Source 1', destination: 'Destination 1' },
 
  ]);
  const [selectedRow, setSelectedRow] = useState(null);

  const handleAddRow = () => {
    setData([...data, { id: data.length + 1, source: '', destination: '' }]);
  };
  const tableHeaderStyle = {
    backgroundColor: '#3887BE',
    color: 'white',
    padding: '10px',
    textAlign: 'center',

  };
  
  const tableCellStyle = {
    border: '1px solid #ddd',
    padding: '8px',
    textAlign: 'center',
  };
  const handleButtonClick = () => {
    setDivVisibility(!isDivVisible);
  };
  const handleDropdownChange = (event) => {
    const value = event.target.value;
    setSelectedValue(event.target.value);
    let fchar = dropdownId.charAt(0);
    if(fchar === 's'){handleSelections(dropdownId, event.target.value);}
    else{
    handleSelection(dropdownId, event.target.value);}
  };

  const handleRemoveRow = () => {
    if (selectedRow !== null) {
      const newData = data.filter((row) => row.id !== selectedRow);
      setData(newData);
      setSelectedRow(null); 
    }
  };

  const handleRowSelect = (id) => {
    setSelectedRow(id === selectedRow ? null : id);
  };

  const handleInputChange = (id, key, value) => {
    const newData = data.map((row) =>
      row.id === id ? { ...row, [key]: value } : row
    );
    setData(newData);
  };

 

  return (
    <div className='dddwn'>
      <div className='cdwn'>
      <select value={selectedValue} onChange={handleDropdownChange} className='dropdowncmp'>
        <option value="" >Select The Field</option>
        {items.map((item) => (
          <option key={item.id} value={item.name}>
            {item.name}
          </option>
        ))}
      </select>
      {ppname === 'desside' && (
        <button className='compbtn' onClick={handleButtonClick}>
          +
        </button>
      )}
      
      </div>
      {isDivVisible && (
        <div className='overlayDiv'>
          <div className='tbldiv'>
          <table style={{ borderCollapse: 'collapse', width: '100%' }}>
      <thead>
        <tr>
          <th style={tableHeaderStyle}>Source</th>
          <th style={tableHeaderStyle}>Destination</th>
        </tr>
      </thead>
      <tbody>
          {data.map((row) => (
            <tr key={row.id} className={row.id === selectedRow ? 'selected' : ''}
            onClick={() => handleRowSelect(row.id)}
            >
              <td>
                <input
                  type="text"
                  value={row.source}
                  onChange={(e) => handleInputChange(row.id, 'source', e.target.value)}
                />
              </td>
              <td>
                <input
                  type="text"
                  value={row.destination}
                  onChange={(e) => handleInputChange(row.id, 'destination', e.target.value)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
      <div className='ctrldiv'>
        <button className='ctrls' onClick={handleAddRow}>   <img src={plus} className='ctrlog'/></button>
        <button className='ctrls' onClick={handleRemoveRow} disabled={selectedRow === null}><img src={minus} className='ctrlog'/> </button>
        <button className='ctrls' onClick={()=>setDivVisibility(false)}><img src={cross} className='ctrlog'/></button>
        <button className='ctrls'><img src={rri} className='ctrlog'/></button>
      </div>
        </div>
      )}
    </div>
  );
}

export default DropdownComponent;
