import { createContext ,useState} from "react";

export const CardContext  =  createContext()

function CardProvider({ children }) {
    const [accessCard, setAccessCard] = useState(null);
  console.log("bb28164a529127f8")
    return (
      <CardContext.Provider value={{accessCard,setAccessCard}}>
          {children}
      </CardContext.Provider>
    );
  }
  
  export { CardProvider };